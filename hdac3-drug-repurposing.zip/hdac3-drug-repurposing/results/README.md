# Results

Output figures are saved here by the notebooks.

| File | Notebook | Description |
|---|---|---|
| `figures/Structural_descriptors_eda.png` | Both | 4×4 countplot grid of structural descriptors by activity class |
| `figures/scatter_plots_eda.png` | Both | Scatter plots: MolWt/HeavyAtomCount vs QED/LogP |
| `figures/top_10_Features.jpg` | Both | Bar chart of top 10 features by mutual information score |
| `figures/confusion_matrix.jpg` | Both | Confusion matrix heatmap for the best model |
| `figures/AUC_ROC.jpg` | Both | ROC curve for the best model (Random Forest) |
| `figures/correlation_matrix.jpg` | Both | Correlation heatmap of the 10 selected descriptors |
| `plot_MolWt_vs_QED.pdf` | Both | MolWt vs QED scatter (publication quality) |
| `MolLogP.pdf` | Both | LogP boxplot by activity class (publication quality) |
